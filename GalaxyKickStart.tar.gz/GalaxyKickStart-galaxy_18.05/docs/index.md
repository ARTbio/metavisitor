# GalaxyKickStart

GalaxyKickStart is an [Ansible](http://www.ansible.com/) playbook designed for installing, testing, deploying and 
maintaining production-grade Galaxy instances.  
In the basic configuration, this includes:

- postgresql server as database backend 
- nginx proxy 
- slurm cluster

In adition, tools and workflows can be managed.
