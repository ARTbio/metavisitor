# Contributors

The following individuals have contributed code to GalaxyKickStart:

* Christophe Antoniewski <drosofff@gmail.com>
* Fabio Rocha Jimenez Vieira <fabiorjvieira@gmail.com>
* Marius van den Beek <m.vandenbeek@gmail.com>
* Nitesh Turaga <nitesh.turaga@gmail.com>
* Enis Afgan <afgane@gmail.com>
* Juliana Pegoraro <juliana.a.pegoraro@gmail.com>
* malloryfreeberg <mallory.freeberg@gmail.com>

# Institutional sponsors

* Institut Universitaire d'Ingénierie et Santé (IUIS)
* Université Paris 6 Pierre et Marie Curie
* Centre National de la Recherche Scientifique (CNRS)
