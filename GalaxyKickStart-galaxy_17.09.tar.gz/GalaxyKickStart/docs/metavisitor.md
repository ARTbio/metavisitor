[Metavisitor](http://journals.plos.org/plosone/article?id=10.1371/journal.pone.0168397) is a set of Galaxy tools and workflows to detect and reconstruct viral genomes from complex deep sequence datasets.

Documentation on Metavisitor installation using GalaxyKickStart is available in the [Metavisitor manual](https://artbio.github.io/Metavisitor-manual/metavisitor_ansible/#installing-metavisitor-with-galaxykickstart-and-ansible)



