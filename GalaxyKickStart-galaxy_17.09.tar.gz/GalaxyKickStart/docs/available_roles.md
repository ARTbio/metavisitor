[ansible-postgresql-objects role](https://github.com/ARTbio/ansible-postgresql-objects/tree/ansible_2.2)
[ensure_postgresql_up role](https://github.com/mvdbeek/ensure_postgresql_up.git)  
[galaxy-extras role](https://github.com/galaxyproject/ansible-galaxy-extras)  
[galaxy-tools role](https://github.com/galaxyproject/ansible-galaxy-tools)  
[galaxy-os role](https://github.com/galaxyproject/ansible-galaxy-os)  
[galaxy role](https://github.com/galaxyproject/ansible-galaxy)  
[ansible-trackster role](https://github.com/galaxyproject/ansible-trackster)
[miniconda role](https://github.com/ARTbio/ansible-miniconda-role.git)
 