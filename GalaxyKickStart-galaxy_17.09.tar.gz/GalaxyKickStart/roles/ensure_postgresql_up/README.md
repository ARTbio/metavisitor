Makes sure postgresql is up and running
-----
Start postgresql either by a supervisor program called postgresql or, if this is not defined,  
through the sustem service. This is required in the context of various galaxyproject ansible roles [1] [2] [3].


1 - https://github.com/galaxyproject/ansible-galaxy-extras  
2 - https://github.com/galaxyproject/ansible-galaxy  
3 - https://github.com/natefoo/ansible-postgresql-objects  
